import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { environment } from '../environmentts/environment';

@Injectable({ providedIn: 'root' })
export class LeaveNotificationService {
  private adminPendingCountSubject = new BehaviorSubject<number>(0);
  private managerPendingCountSubject = new BehaviorSubject<number>(0);

  adminPendingCount$ = this.adminPendingCountSubject.asObservable();
  managerPendingCount$ = this.managerPendingCountSubject.asObservable();

  setAdminPendingCount(count: number) {
    this.adminPendingCountSubject.next(count);
  }

  setManagerPendingCount(count: number) {
    this.managerPendingCountSubject.next(count);
  }

  getAdminPendingCount(): number {
    return this.adminPendingCountSubject.value;
  }

  getManagerPendingCount(): number {
    return this.managerPendingCountSubject.value;
  }
}



@Injectable({
  providedIn: 'root'
})
export class ApiService {

  // LeaveCount
  getAllLeaveCounts() {
    const token = sessionStorage.getItem('authToken');
    const headers = { Authorization: `Bearer ${token}` };
    const url = `${environment.baseurl}${environment.GetAllLeaveCounts}`;
    return this.http.get<any>(url, { headers }).pipe(map(res => res));
  }
forgotPassword(payload: { Email: string }): Observable<any> {
    const url = `${environment.baseurl}${environment.GetForgotPassword}`;
    return this.http.post<any>(url, payload).pipe(map(res => res));
  }
 
  verifyOtp(payload: { Email: string, Otp: string }): Observable<any> {
    const url = `${environment.baseurl}${environment.VerifyOtp}`;
    return this.http.post<any>(url, payload).pipe(map(res => res));
  }
 
  resetPassword(payload: { Email: string, NewPassword: string, ConfirmPassword: string }): Observable<any> {
    const url = `${environment.baseurl}${environment.ResetPassword}`;
    return this.http.post<any>(url, payload).pipe(map(res => res));
  }
 
  verifyOldPassword(payload: { Email: string; OldPassword: string }): Observable<any> {
    const token = sessionStorage.getItem('authToken');
    const headers = { Authorization: `Bearer ${token}` };
 
    const url = `${environment.baseurl}${environment.VerifyOldPassword}`;
    return this.http.post<any>(url, payload, { headers }).pipe(map(res => res));
  }

  
 
  changePassword(payload: { Email: string; OldPassword: string; NewPassword: string; ConfirmPassword: string }): Observable<any> {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };
  const url = `${environment.baseurl}${environment.ChangePassword}`;
  return this.http.post<any>(url, payload, { headers }).pipe(map(res => res));
}

  constructor(private http: HttpClient) {}

 

  login(payload: { email: string, password: string }): Observable<any> {
  const url = `${environment.baseurl}${environment.GetLogin}`;
  return this.http.post<any>(url, payload).pipe(
    map(res => {
      if (res && res.token) {
        sessionStorage.setItem('authToken', res.token); // <-- Store token
      }
      return res;
    })
  );
}

getUsersByCompany(companyId: number) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.GetUsersByComapanyId.replace('{companyId}', companyId.toString())}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}

  // Fetch company details by company id
  getCompanyById(companyId: number) {
    const token = sessionStorage.getItem('authToken');
    const headers = { Authorization: `Bearer ${token}` };

    const url = `${environment.baseurl}${environment.GetCompanyById.replace('{companyId}', companyId.toString())}`;
    return this.http.get<any>(url, { headers }).pipe(map(res => res));
  }

  // Lookup helpers: department / designation / role names by id
  getDepartmentName(departmentId: number) {
    const token = sessionStorage.getItem('authToken');
    const headers = { Authorization: `Bearer ${token}` };
    const url = `${environment.baseurl}${environment.GetDepartmentName.replace('{departmentId}', departmentId.toString())}`;
    return this.http.get<any>(url, { headers }).pipe(map(res => res));
  }

  getDesignationName(designationId: number) {
    const token = sessionStorage.getItem('authToken');
    const headers = { Authorization: `Bearer ${token}` };
    const url = `${environment.baseurl}${environment.GetDesignationName.replace('{designationId}', designationId.toString())}`;
    return this.http.get<any>(url, { headers }).pipe(map(res => res));
  }

  getRoleName(roleId: number) {
    const token = sessionStorage.getItem('authToken');
    const headers = { Authorization: `Bearer ${token}` };
    const url = `${environment.baseurl}${environment.GetRoleName.replace('{roleId}', roleId.toString())}`;
    return this.http.get<any>(url, { headers }).pipe(map(res => res));
  }

  // Fetch all departments
  getAllDepartments() {
    const token = sessionStorage.getItem('authToken');
    const headers = { Authorization: `Bearer ${token}` };
    const url = `${environment.baseurl}${environment.GetAllDepartments}`;
    return this.http.get<any>(url, { headers }).pipe(map(res => res));
  }

  // Fetch all designations
  getAllDesignations() {
    const token = sessionStorage.getItem('authToken');
    const headers = { Authorization: `Bearer ${token}` };
    const url = `${environment.baseurl}${environment.GetAllDesignations}`;
    return this.http.get<any>(url, { headers }).pipe(map(res => res));
  }

  // Fetch all roles
  getAllRoles() {
    const token = sessionStorage.getItem('authToken');
    const headers = { Authorization: `Bearer ${token}` };
    const url = `${environment.baseurl}${environment.GetAllRoles}`;
    return this.http.get<any>(url, { headers }).pipe(map(res => res));
  }



getOfficeAddressById(id: number) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.GetOfficeAddressById.replace('{id}', id.toString())}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}


//weekly-Timesheet
  saveWeeklyTimesheet(payload: any) {
    const token = sessionStorage.getItem('authToken');
    const headers = { Authorization: `Bearer ${token}` };
 
    const url = `${environment.baseurl}${environment.SaveWeeklyTimesheet}`;
    return this.http.post<any>(url, payload, { headers }).pipe(map(res => res));
    }
 
  getWeeklyTimesheet() {
    const token = sessionStorage.getItem('authToken');
    const headers = { Authorization: `Bearer ${token}` };
    const url = `${environment.baseurl}${environment.GetWeeklyTimesheet}`;
    return this.http.get<any>(url, { headers }).pipe(map(res => res));
  }

  GetAllTimesheetLeave(){
    const token = sessionStorage.getItem('authToken');
    const headers = { Authorization: `Bearer ${token}` };
    const url = `${environment.baseurl}${environment.GetAllTimesheetLeave}`;
    return this.http.get<any>(url, { headers }).pipe(map(res => res));
  }
  saveTimesheetLeave(payload: any) {
    const token = sessionStorage.getItem('authToken');
    const headers = { Authorization: `Bearer ${token}` };
    const url = `${environment.baseurl}${environment.SaveTimesheetLeave}`;
    return this.http.post<any>(url, payload, { headers }).pipe(map(res => res));
  } 

// Users
getAllUsers() {
  const token = sessionStorage.getItem('authToken');
  const headers = {
    Authorization: `Bearer ${token}`
  };
    return this.http.get<any>(
    `${environment.baseurl}${environment.GetAllUsers}`,
    { headers }
  ).pipe(map(res => res));
}
  

getUserById(id: string) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.GetUserById.replace('{id}', id.toString())}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}

  // saveUser(payload: any) {
  //   return this.http.post<any>(`${environment.baseurl}${environment.SaveUser}`, payload).pipe(map(res => res));
  // }

  saveUser(payload: any): Observable<any> {
    return this.http.post<any>(
      `${environment.baseurl}${environment.SaveUser}`,
      payload
    ).pipe(map(res => res));
  }

  deleteUser(id: string) {
    return this.http.get<any>(`${environment.baseurl}${environment.DeleteUser.replace('{id}', id.toString())}`).pipe(map(res => res));
  }

  // // Attendance
  // getAllAttendances() {
  //   return this.http.get<any>(`${environment.baseurl}${environment.GetAllAttendances}`).pipe(map(res => res));
  // }


  getAllAttendances() {
  const token = sessionStorage.getItem('authToken');
  const headers = {
    Authorization: `Bearer ${token}`
  };

  return this.http.get<any>(
    `${environment.baseurl}${environment.GetAllAttendances}`,
    { headers }
  ).pipe(map(res => res));
}



  // getAttendanceById(id: number) {
  //   return this.http.get<any>(`${environment.baseurl}${environment.GetAttendanceById.replace('{id}', id.toString())}`).pipe(map(res => res));
  // }

  //   getAttendanceByEmpId(id: string) {
  //   return this.http.get<any>(`${environment.baseurl}${environment.GetAttendanceByEmpId.replace('{id}', id)}`).pipe(map(res => res));
  // }

  // saveAttendance(payload: any) {
  //   return this.http.post<any>(`${environment.baseurl}${environment.SaveAttendance}`, payload).pipe(map(res => res));
  // }




  getAttendanceById(id: number) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.GetAttendanceById.replace('{id}', id.toString())}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}



getAttendanceByEmpId(id: string) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.GetAttendanceByEmpId.replace('{id}', id)}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}

saveAttendance(payload: any) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.SaveAttendance}`;
  return this.http.post<any>(url, payload, { headers }).pipe(map(res => res));
}


saveAttendanceRegularization(payload: any) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.SaveAttendanceRegularization}`;
  return this.http.post<any>(url, payload, { headers }).pipe(map(res => res));
}


  // deleteAttendance(id: number) {
  //   return this.http.delete<any>(`${environment.baseurl}${environment.DeleteAttendance.replace('{id}', id.toString())}`).pipe(map(res => res));
  // }

  

  

  // // Leave Application
  getAllLeaveRequests() {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.GetAllLeaveRequests}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}

getLeaveRequestById(id: number) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.GetLeaveRequestById.replace('{id}', id.toString())}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}

getLeaveRequestByEmpId(id: string) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.GetLeaveRequestByEmpId.replace('{id}', id)}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}

saveLeaveRequest(payload: any) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.SaveLeaveRequest}`;
  return this.http.post<any>(url, payload, { headers }).pipe(map(res => res));
}

deleteLeaveRequest(id: number) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.DeleteLeaveRequest.replace('{id}', id.toString())}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}




// DailyTasks

getAllDailyTasks() {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.GetAllDailyTasks}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}

getDailyTaskById(id: number) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.GetDailyTaskById.replace('{id}', id.toString())}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}

getDailyTaskByEmpId(id: string) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.GetDailyTaskByEmpId.replace('{id}', id)}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}

saveDailyTask(payload: any) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.SaveDailyTask}`;
  return this.http.post<any[]>(url, payload, { headers }).pipe(map(res => res));
}

uploadDailyTaskExcel(file: File) {
  const token = sessionStorage.getItem('authToken');
  const headers = {
    Authorization: `Bearer ${token}`
  };
 
  const formData = new FormData();
  formData.append('file', file, file.name);
 
  return this.http.post(
    `${environment.baseurl}${environment.UploadDailyTaskExcel}`,
    formData,
    {
      headers,
      reportProgress: true,
      observe: 'events'
    }
  );
}

deleteDailyTask(id: number) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.DeleteDailyTask.replace('{id}', id.toString())}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}




// Holiday

getAllHolidays() {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.GetAllHolidays}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}

getHolidayById(id: number) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.GetHolidayById.replace('{id}', id.toString())}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}

saveHoliday(payload: any) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.SaveHoliday}`;
  return this.http.post<any>(url, payload, { headers }).pipe(map(res => res));
}

deleteHoliday(id: number) {
  const token = sessionStorage.getItem('authToken');
  const headers = { Authorization: `Bearer ${token}` };

  const url = `${environment.baseurl}${environment.DeleteHoliday.replace('{id}', id.toString())}`;
  return this.http.get<any>(url, { headers }).pipe(map(res => res));
}

  
}
