import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import * as XLSX from 'xlsx';
import { environment } from '../../../environmentts/environment';
import { ApiService } from '../../../services/services';
// import { environment } from '../../../environmentts/environment'; 

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [CommonModule, FormsModule,ToastModule],
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  loggedInRole: string = '';
  showToast(severity: string, summary: string, detail: string, options: any = {}) {
    this.messageService.add({ severity, summary, detail, ...options });
  }

  constructor(
    private http: HttpClient,
    private messageService: MessageService,
    private router: Router,
    private apiService: ApiService
  ) {}
  searchText = '';
  filterRole = '';
  employees: any[] = [];
  private baseUrl = environment.baseurl;
  // employees: any[] = [];
  isLoading: boolean = false;
  selectedEmployee: any = null;

  // Show/hide filter input for each column
  showFilter: { [key: string]: boolean } = {
    empId: false,
    joiningDate: false,
    firstName: false,
    middleName: false,
    lastName: false,
    userName: false,
    dateOfBirth: false,
    mobileNumber: false,
    gender: false,
    email: false,
    department: false,
    designation: false,
    companyName: false,
    address: false,
    holiday: false,
    reportingManager: false,
    role: false
  };

  // Filter value for each column
  columnFilters: { [key: string]: string } = {
    empId: '',
    joiningDate: '',
    firstName: '',
    middleName: '',
    lastName: '',
    userName: '',
    dateOfBirth: '',
    mobileNumber: '',
    gender: '',
    email: '',
    department: '',
    designation: '',
    companyName: '',
    address: '',
    holiday: '',
    reportingManager: '',
    role: ''
  };

  toggleFilter(column: string) {
    this.showFilter[column] = !this.showFilter[column];
    if (!this.showFilter[column]) {
      this.columnFilters[column] = '';
    }
  }
  ngOnInit(): void {
    this.fetchEmployees(); 
    
    // Get logged-in user's role from sessionStorage (adjust key as needed)
    const userRole = sessionStorage.getItem('userRole');
    if (userRole) {
      // If stored as a string (e.g., 'Admin'), use directly
      if (userRole.startsWith('{')) {
        try {
          const user = JSON.parse(userRole);
          this.loggedInRole = user.role ? user.role.toLowerCase() : '';
        } catch (e) {
          this.loggedInRole = '';
        }
      } else {
        this.loggedInRole = userRole.toLowerCase();
      }
    }
    
  }
  // ngOnInit(): void {
  //   this.fetchEmployees(); 
  // }

  // fetch api for get all emp 
  fetchEmployees() {
    this.isLoading = true;
    this.apiService.getAllUsers().subscribe({
      next: (data: any) => {
        this.employees = data;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error fetching employees:', err);
        this.showToast('error', 'Error', 'Failed to load employee data.');
        this.isLoading = false;
      }
    });
  }


  downloadTableAsExcel(table: HTMLElement): void {
  const worksheet: XLSX.WorkSheet = XLSX.utils.table_to_sheet(table);
  const workbook: XLSX.WorkBook = {
    Sheets: { 'Employees': worksheet },
    SheetNames: ['Employees']
  };

  const excelBuffer: any = XLSX.write(workbook, {
    bookType: 'xlsx',
    type: 'array'
  });

  const blob: Blob = new Blob([excelBuffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });

  const url = window.URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
    // Format date as yyyy-MM-dd
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const formattedDate = `${yyyy}-${mm}-${dd}`;
    const fileName = `Employee_Details_${formattedDate}.xlsx`;
    anchor.download = fileName;
  anchor.click();
  window.URL.revokeObjectURL(url);
}
  
//   getAllUsers() {
//   this.http.get(`${this.baseUrl}${environment.GetAllUsers}`).subscribe({
//     next: (data: any) => {
//       console.log('API Response:', data); // ✅ Now you see actual response
//       this.employees = data;              // Optional: store in employees
//     },
//     error: (err) => {
//       console.error('Error fetching users:', err);
//     }
//   });
// }
  CreatePage() {
    this.router.navigate(['/create-page']);
  }

  ViewPage() {
    if (!this.selectedEmployee) {
      this.showToast('warn', 'Warning', 'Please select an employee first');
      return;
    }
    
    this.router.navigate(['/create-page'], {
      state: { 
        employeeData: this.selectedEmployee,
        viewMode: true
      }
    });
  }

  EditPage() {
    if (!this.selectedEmployee) {
      this.showToast('warn', 'Warning', 'Please select an employee first');
      return;
    }
    
    this.router.navigate(['/create-page'], {
      state: { 
        employeeData: this.selectedEmployee,
        editMode: true
      }
    });
  }


  selectEmployee(employee: any) {
    this.selectedEmployee = employee;
  }

  // get filteredRecords() {
  //   return this.employees.filter(emp => {
  //     const searchMatch = !this.searchText ||
  //       emp.firstname.toLowerCase().includes(this.searchText.toLowerCase()) ||
  //       emp.empId.toLowerCase().includes(this.searchText.toLowerCase());
      
  //     const dateMatch = !this.filterDate || 
  //       emp.date === this.filterDate;
      
  //     return searchMatch && dateMatch;
  //   });
  // }

  get filteredRecords() {
      return this.employees.filter(record => {
        // Global search (name or ID)
        const fullName = `${record.firstName || ''} ${record.middleName || ''} ${record.lastName || ''}`.toLowerCase();
        const searchMatch = !this.searchText ||
          fullName.includes(this.searchText.toLowerCase()) ||
          (record.empId && record.empId.toLowerCase().includes(this.searchText.toLowerCase()));

        // Role filter
        const roleMatch = !this.filterRole ||
          (record.role && record.role.toLowerCase() === this.filterRole.toLowerCase());

        // Column filters
        const columnMatch = Object.keys(this.columnFilters).every(key => {
          if (!this.columnFilters[key]) return true;
          const value = (record[key] || '').toString().toLowerCase();
          return value.includes(this.columnFilters[key].toLowerCase());
        });

        return searchMatch && roleMatch && columnMatch;
      });
  }

private toLocalDateString(date: string | Date): string {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = (d.getMonth() + 1).toString().padStart(2, '0');
  const day = d.getDate().toString().padStart(2, '0');
  return `${year}-${month}-${day}`;
}

}
