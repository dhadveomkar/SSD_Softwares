import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import * as XLSX from 'xlsx';
import { ApiService } from '../../../services/services';


interface User {
  empId: string;
  managerId: string | null;
  isManagerAssigned: boolean;
  userName: string;
  firstName: string;
  middleName: string;
  lastName: string;
  email: string;
  password: string;
  gender: string;
  address: string;
  mobileNumber: string;
  dateOfBirth: string;
  department: string;
  role: string;
  designation: string;
  joiningDate: string;
  reportingManager: string;
  companyName: string;
  holiday: string;
  Timesheet: string;
}

@Component({
  selector: 'app-create-page',
  standalone: true,
  imports: [FormsModule, CommonModule, ToastModule],
  providers: [MessageService],
  templateUrl: './create-page.component.html',
  styleUrls: ['./create-page.component.css']
})
export class CreatePageComponent {
  // Helper to safely get uploaded file name from the file input
  get uploadedFileName(): string {
    const input = document.getElementById('csvFileInputModal') as HTMLInputElement | null;
    if (input && input.files && input.files.length > 0) {
      return input.files[0].name;
    }
    return '';
  }
  /**
   * Transform a raw employee object from upload to the expected format
   */
    // Returns a download URL for the uploaded file
    getUploadedFileUrl(input: HTMLInputElement): string {
      if (input && input.files && input.files.length > 0) {
        return URL.createObjectURL(input.files[0]);
      }
      return '';
    }
  transformEmployeePayload(raw: any): User {
    // Helper to convert Excel serial date to yyyy-MM-dd
    function excelSerialToDate(serial: any): string {
      if (typeof serial === 'number') {
        const excelEpoch = new Date(Date.UTC(1899, 11, 30));
        const days = Math.floor(serial);
        const ms = days * 24 * 60 * 60 * 1000;
        const date = new Date(excelEpoch.getTime() + ms);
        return date.toISOString().split('T')[0];
      }
      return '';
    }

    // Helper to normalize date string
    function normalizeDate(val: any): string {
      if (val === null || val === undefined || val === '' || val === '-') return '';
      if (typeof val === 'number') return excelSerialToDate(val);
      if (typeof val === 'string') {
        // Try to parse as date
        const d = new Date(val);
        if (!isNaN(d.getTime())) return d.toISOString().split('T')[0];
      }
      return '';
    }

    // Helper to normalize string/null
    function normalize(val: any): string {
      if (val === null || val === undefined || val === '' || val === '-') return '';
      return String(val);
    }

    // Map fields
    return {
      empId: normalize(raw['Employee ID'] ?? raw['empId']),
      managerId: normalize(raw['Reporting Manager'] ?? raw['managerId']),
      isManagerAssigned: !!(raw['Reporting Manager'] ?? raw['managerId']),
      userName: normalize(raw['User Name'] ?? raw['userName']),
      firstName: normalize(raw['First Name'] ?? raw['firstName']),
      middleName: normalize(raw['Middle Name'] ?? raw['middleName']),
      lastName: normalize(raw['Last Name'] ?? raw['lastName']),
      email: normalize(raw['Email'] ?? raw['email']),
      password: normalize(raw['Password'] ?? raw['password']),
      gender: normalize(raw['Gender'] ?? raw['gender']),
      address: normalize(raw['Address'] ?? raw['address']),
      mobileNumber: normalize(raw['Mobile Number'] ?? raw['mobileNumber']),
      dateOfBirth: normalizeDate(raw['Date of Birth'] ?? raw['dateOfBirth']),
      department: normalize(raw['Department'] ?? raw['department']),
      role: normalize(raw['Role'] ?? raw['role']),
      designation: normalize(raw['Designation'] ?? raw['designation']),
      joiningDate: normalizeDate(raw['Joining Date'] ?? raw['joiningDate']),
      reportingManager: normalize(raw['Reporting Manager'] ?? raw['reportingManager']),
      companyName: normalize(raw['Company Name'] ?? raw['companyName']),
      holiday: normalize(raw['Holiday'] ?? raw['holiday']),
      Timesheet: normalize(raw['Timesheet'] ?? raw['timesheet'] ?? raw['timeSheet'])
    };
  }
  showUploadModal = false;
  pendingEmployees: any[] = [];
  // Handle drag-and-drop file upload in modal
  onFileDrop(event: DragEvent) {
    event.preventDefault();
    if (event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files.length > 0) {
      const fileInput = document.querySelector<HTMLInputElement>("#csvFileInputModal");
      if (fileInput) {
        // Set files to input and trigger change event
        fileInput.files = event.dataTransfer.files;
        const changeEvent = new Event('change', { bubbles: true });
        fileInput.dispatchEvent(changeEvent);
        this.showUploadModal = false;
      }
    }
  }
  // Handle CSV or Excel file selection and parse only
  onCsvFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) {
      this.messageService.add({
        severity: 'error',
        summary: 'Error',
        detail: 'No file selected.',
        life: 4000
      });
      this.pendingEmployees = [];
      return;
    }
    const file = input.files[0];
    const fileName = file.name.toLowerCase();
    if (fileName.endsWith('.xlsx')) {
      // Excel file handling
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        let jsonData: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
        if (jsonData.length === 0) {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Excel file is empty.',
            life: 4000
          });
          this.pendingEmployees = [];
          return;
        }
        // Convert Excel serial date numbers to ISO strings for dateOfBirth and joiningDate
        jsonData = jsonData.map(emp => {
          ['dateOfBirth', 'joiningDate'].forEach(field => {
            if (emp[field] && typeof emp[field] === 'number') {
              // Excel date serial to JS Date
              const excelEpoch = new Date(Date.UTC(1899, 11, 30));
              const days = Math.floor(emp[field]);
              const ms = days * 24 * 60 * 60 * 1000;
              const date = new Date(excelEpoch.getTime() + ms);
              emp[field] = date.toISOString().split('T')[0] + 'T00:00:00';
            }
          });
          return emp;
        });
  this.pendingEmployees = jsonData;
  this.showToastSuccess('File upload successfully.', 3000);
      };
      reader.readAsArrayBuffer(file);
    } else if (fileName.endsWith('.csv')) {
      // CSV file handling
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const csvText = e.target.result;
        const lines = csvText.split(/\r?\n/).filter((line: string) => line.trim() !== '');
        if (lines.length === 0) {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'CSV file is empty.',
            life: 4000
          });
          this.pendingEmployees = [];
          return;
        }
        // Required fields in order (A, B, C, ...)
        const requiredHeaders = ['empId','managerId','isManagerAssigned','userName','firstName','middleName','lastName','email','password','gender','mobileNumber','dateOfBirth','department','role','designation','joiningDate','reportingManager'];
        let employees: any[] = [];
        // Detect header by checking if first row contains any of the required field names
        const firstLine = lines[0].split(',').map((h: string) => h.trim().toLowerCase());
        const hasHeader = requiredHeaders.some(h => firstLine.includes(h.toLowerCase()));
        if (hasHeader) {
          // Use header mapping as before
          const headers = lines[0].split(',').map((h: string) => h.trim());
          const missingHeaders = ['empId','userName','firstName','lastName','email','password','gender','mobileNumber','dateOfBirth','department','role','designation','joiningDate','reportingManager'].filter((h: string) => !headers.includes(h));
          if (missingHeaders.length > 0) {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Missing required columns: ' + missingHeaders.join(', '),
              life: 4000
            });
            this.pendingEmployees = [];
            return;
          }
          employees = lines.slice(1).map((line: string) => {
            const values = line.split(',');
            const employee: any = {};
            headers.forEach((header: string, idx: number) => {
              if (header === 'dateOfBirth' || header === 'joiningDate') {
                let dateVal = values[idx] ? values[idx].trim() : '';
                if (dateVal && dateVal.includes('/')) {
                  const parts = dateVal.split('/');
                  if (parts.length === 3) {
                    const yyyy = parts[2].length === 4 ? parts[2] : '20' + parts[2];
                    const mm = parts[0].padStart(2, '0');
                    const dd = parts[1].padStart(2, '0');
                    dateVal = `${yyyy}-${mm}-${dd}`;
                  }
                }
                employee[header] = dateVal;
              } else {
                employee[header] = values[idx] ? values[idx].trim() : '';
              }
            });
            // Always set 'user' field from userName or email
            employee.user = employee.userName ? employee.userName : (employee.email ? employee.email : '');
            return employee;
          });
        } else {
          // No header: map columns by fixed order (A, B, C, ...)
          employees = lines.map((line: string) => {
            const values = line.split(',');
            const employee: any = {};
            const fieldOrder = [
              'empId',
              'managerId',
              'isManagerAssigned',
              'userName',
              'firstName',
              'middleName',
              'lastName',
              'email',
              'password',
              'gender',
              'address',
              'mobileNumber',
              'dateOfBirth',
              'department',
              'designation',
              'role',
              'joiningDate',
              'reportingManager'
            ];
            fieldOrder.forEach((field: string, idx: number) => {
              if (field === 'isManagerAssigned') {
                const val = values[idx] ? values[idx].trim().toLowerCase() : '';
                employee[field] = (val === '1' || val === 'true') ? true : false;
              } else if (field === 'dateOfBirth' || field === 'joiningDate') {
                let dateVal = values[idx] ? values[idx].trim() : '';
                if (dateVal && dateVal.includes('/')) {
                  const parts = dateVal.split('/');
                  if (parts.length === 3) {
                    const yyyy = parts[2].length === 4 ? parts[2] : '20' + parts[2];
                    const mm = parts[0].padStart(2, '0');
                    const dd = parts[1].padStart(2, '0');
                    dateVal = `${yyyy}-${mm}-${dd}`;
                  }
                }
                employee[field] = dateVal;
              } else {
                employee[field] = values[idx] ? values[idx].trim() : '';
              }
            });
            employee.user = employee.userName ? employee.userName : (employee.email ? employee.email : '');
            return employee;
          });
        }
  this.pendingEmployees = employees;
  this.showToastSuccess('File upload successfully.', 3000);
      };
      reader.readAsText(file);
    } else {
      this.messageService.add({
        severity: 'error',
        summary: 'Error',
        detail: 'Unsupported file type. Please upload a CSV or Excel file.',
        life: 4000
      });
      this.pendingEmployees = [];
    }
  }
  // Called when user clicks Proceed in modal
  onProceedUpload() {
    if (!this.pendingEmployees || this.pendingEmployees.length === 0) {
      this.messageService.add({
        severity: 'error',
        summary: 'Error',
        detail: 'File not uploaded please upload a file first.',
        life: 3000
      });
      return;
    }
      // Transform all employees to expected format before upload
      const transformed = this.pendingEmployees.map(emp => this.transformEmployeePayload(emp));
      this.processEmployeeUpload(transformed);
      this.pendingEmployees = [];
      this.showUploadModal = false;
  }

  // Common upload logic for both CSV and Excel
  private processEmployeeUpload(employees: any[]) {
    if (!employees || employees.length === 0) {
      this.messageService.add({
        severity: 'error',
        summary: 'Error',
        detail: 'No employee data found in file.',
        life: 4000
      });
      return;
    }
    // Print parsed employees to console for debugging
    console.log('Parsed employees from file:', employees);
    // Fetch all users once for duplicate check
    this.apiService.getAllUsers().subscribe({
      next: (existingUsers: any[]) => {
        let successCount = 0;
        let errorCount = 0;
        let duplicateCount = 0;
        const total = employees.length;
        const navigateToList = () => {
          setTimeout(() => {
            this.router.navigate(['/employee-list']);
          }, 3000);
        };
        employees.forEach((emp: any) => {
          const empIdExists = existingUsers.some(u => u.empId === emp.empId);
          const userNameExists = existingUsers.some(u => u.userName === emp.userName);
          const emailExists = existingUsers.some(u => u.email === emp.email);
          if (empIdExists || userNameExists || emailExists) {
            duplicateCount++;
            errorCount++;
            if (successCount + errorCount === total) {
              if (successCount === 0) {
                this.messageService.add({
                  severity: 'error',
                  summary: 'Error',
                  detail: 'This employee details already present.',
                  life: 5000
                });
                navigateToList();
              } else {
                this.showToastSuccess(`Creating ${successCount} employees details successfully.`);
                navigateToList();
              }
            }
            return;
          }
          this.apiService.saveUser(emp).subscribe({
            next: () => {
              successCount++;
              if (successCount + errorCount === total) {
                this.showToastSuccess(`Creating ${successCount} employees details successfully.`);
                navigateToList();
              }
            },
            error: () => {
              errorCount++;
              if (successCount + errorCount === total) {
                this.messageService.add({
                  severity: 'error',
                  summary: 'Error',
                  detail: `Failed to upload employees details.`,
                  life: 3000
                });
                navigateToList();
              }
            }
          });
        });
      },
      error: () => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to check for duplicates.',
          life: 3000
        });
      }
    });
  }
  showPassword = false;
  // Prevent non-digit characters in mobile number input
  onMobileNumberInput(event: Event) {
    const input = event.target as HTMLInputElement | null;
    if (!input) return;
    // Remove all non-digit characters
    input.value = input.value.replace(/\D/g, '');
    this.formData.mobileNumber = input.value;
  }
    // Mark all form fields as touched to show validation errors
    markFormFieldsTouched(form: any) {
      if (form && form.controls) {
        Object.values(form.controls).forEach((control: any) => {
          control.markAsTouched();
        });
      }
    }
  today = new Date().toISOString().split('T')[0];

  // Returns true if the given date string (yyyy-MM-dd) is in the future compared to today
  isFutureDate(date: string): boolean {
    if (!date) return false;
    const inputDate = new Date(date);
    const todayDate = new Date(this.today);
    // Remove time part for strict date comparison
    inputDate.setHours(0,0,0,0);
    todayDate.setHours(0,0,0,0);
    return inputDate > todayDate;
  }

  // Prevent typing more than 4 digits in year for date of birth
  onDateOfBirthInput(event: Event) {
    const input = event.target as HTMLInputElement | null;
    if (!input || typeof input.value !== 'string') return;
    const value = input.value;
    // Only allow yyyy-MM-dd, block if year > 4 digits
    const match = value.match(/^(\d{4})(\d*)-(\d{0,2})-(\d{0,2})$/);
    if (match && match[2] && match[2].length > 0) {
      // Remove extra digits from year
      input.value = match[1] + '-' + match[3] + '-' + match[4];
      this.formData.dateOfBirth = input.value;
    }
  }
  
  // Prevent typing more than 4 digits in year for joining date
  onJoiningDateInput(event: Event) {
    const input = event.target as HTMLInputElement | null;
    if (!input || typeof input.value !== 'string') return;
    const value = input.value;
    // Only allow yyyy-MM-dd, block if year > 4 digits
    const match = value.match(/^(\d{4})(\d*)-(\d{0,2})-(\d{0,2})$/);
    if (match && match[2] && match[2].length > 0) {
      // Remove extra digits from year
      input.value = match[1] + '-' + match[3] + '-' + match[4];
      this.formData.joiningDate = input.value;
    }
  }
  showToastSuccess(message: string, life: number = 3000) {
    this.messageService.add({
      severity: 'success',
      summary: 'Success',
      detail: message,
      life: life
    });
  }
  loggedInRole: string = '';
  router = inject(Router);
  apiService = inject(ApiService);
  messageService = inject(MessageService);
  
  isViewMode: boolean = false;
  isEditMode: boolean = false;
  originalData: any = null;
  managers: User[] = []; // Store the full manager objects

  formData = {
    empId: '',
    managerId: '',
    isManagerAssigned: false,
    firstName: '',
    middleName: '',
    lastName: '',
    userName: '',
    dateOfBirth: '',
    mobileNumber: '',
    gender: '',
    address: '',
    email: '',
    department: '',  
    designation: '',
    joiningDate: '',
    reportingManager: '',
    role: '',
    password: '',
    companyName: '',
    holiday: '',
    timesheet: ''
  };

  genders = [
    { label: 'Male', value: 'Male' },
    { label: 'Female', value: 'Female' },
    { label: 'Other', value: 'Other' }
  ];

  roles = [
    { label: 'Admin', value: 'admin' },
    { label: 'User', value: 'user' },
    { label: 'Manager', value: 'manager' }
  ];

  holidayOptions: string[] = []; // Default options

  // Set managerId and reportingManager when a manager is selected
  setReportingManager(selectedManagerEmpId: string) {
    this.formData.managerId = selectedManagerEmpId;
    this.formData.reportingManager = selectedManagerEmpId;
    this.formData.isManagerAssigned = !!selectedManagerEmpId;
  }

  // Fetch holidays from API when select box is clicked
  fetchHolidayOptions() {
    this.apiService.getAllHolidays().subscribe({
      next: (existing: any[]) => {
        if (Array.isArray(existing) && existing.length > 0) {
          // Map to string names and remove duplicates
          const names = existing.map(h => h.holidaySet);
          this.holidayOptions = Array.from(new Set(names));
        }
      },
      error: () => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to load holiday options.',
          life: 3000
        });
      }
    });
  }

  // Managers = [
  //   {label:'X', value:'x'},
  //   {label:'Y', value:'Y'},
  //   {label:'Z', value:'Z'}

  // ]
  constructor() {
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras?.state as {employeeData: any, viewMode: boolean, editMode: boolean};

    // Get logged-in user's role from sessionStorage (adjust key as needed)
    const userRole = sessionStorage.getItem('userRole');
    if (userRole) {
      if (userRole.startsWith('{')) {
        try {
          const user = JSON.parse(userRole);
          this.loggedInRole = user.role ? user.role.toLowerCase() : '';
        } catch (e) {
          this.loggedInRole = '';
        }
      } else {
        this.loggedInRole = userRole.toLowerCase();
      }
    }

    if (state?.employeeData) {
      // Create a copy of the employee data
      const employeeData = { ...state.employeeData };
      // Format the date if it exists
      if (employeeData.dateOfBirth || employeeData.joiningDate) {
        employeeData.dateOfBirth = this.formatDateForInput(employeeData.dateOfBirth);
        employeeData.joiningDate = this.formatDateForInput(employeeData.joiningDate);
      }
      // Assign the formatted data to formData
  // Ensure timeSheet is present in formData
  this.formData = { ...employeeData, timesheet: employeeData.timesheet || employeeData.timeSheet || '' };
  this.originalData = { ...employeeData, timesheet: employeeData.timesheet || employeeData.timeSheet || '' };
      this.isViewMode = state.viewMode || false;
      this.isEditMode = state.editMode || false;
    } else {
      // Navigated without state (e.g., via Create Employee dropdown): reset to create mode
      this.isViewMode = false;
      this.isEditMode = false;
      this.formData = {
        empId: '',
        managerId: '',
        isManagerAssigned: false, 
        firstName: '',
        middleName: '',
        lastName: '',
        userName: '',      
        dateOfBirth: '',
        mobileNumber: '',
        gender: '',
        address: '',
        email: '', 
        department: '',  
        role: '',
        password: '',
        joiningDate: '',
        reportingManager:'',
        designation:'',
        companyName: '',
        holiday: '',
        timesheet: ''
      };
      this.originalData = null;
    }

    this.loadManagers();
  }

  // Add this method to fetch and filter managers
  private loadManagers() {
    this.apiService.getAllUsers().subscribe({
      next: (users: User[]) => {
        // Filter users with role 'Manager' (case-insensitive)
        this.managers = users.filter(user => 
          user.role && user.role.toLowerCase() === 'manager' || user.role.toLowerCase() === 'admin'
        );
        
        // If editing and has a reporting manager, ensure it's in the list
        if (this.formData.reportingManager) {
          const currentManagerExists = this.managers.some(
            m => m.empId === this.formData.reportingManager
          );
          
          if (!currentManagerExists) {
            // Try to find the manager in the full users list
            const missingManager = users.find(
              u => u.empId === this.formData.reportingManager
            );
            
            if (missingManager) {
              this.managers.push(missingManager);
            }
          }
        }
      },
      error: (err) => {
        console.error('Failed to load managers:', err);
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to load managers list',
          life: 3000
        });
      }
    });
  }

  // Helper function to convert date to yyyy-MM-dd format
  private formatDateForInput(dateString: string): string {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  
  isAdminRole(): boolean {
    return !!this.formData.role && this.formData.role.toLowerCase() === 'admin';
  }

  updateEmployee() {
    // Employee ID format validation removed as per new requirements

    

    // Check for duplicate Employee ID, userName, and email only when creating (not editing)
    if (!this.isEditMode) {
      this.apiService.getAllUsers().subscribe({
        next: (users: User[]) => {
          const empIdExists = users.some(u => u.empId === this.formData.empId);
          if (empIdExists) {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'This Employee ID is already used. Please use another.',
              life: 4000
            });
            return;
          }
          const userNameExists = users.some(u => u.userName === this.formData.userName);
          console.log(userNameExists);
          
          if (userNameExists) {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'This Username is already used. Please use another.',
              life: 4000
            });
            return;
          }
          const emailExists = users.some(u => u.email === this.formData.email);
          if (emailExists) {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'This Email is already used. Please use another.',
              life: 4000
            });
            return;
          }
          this.saveEmployee();
        },
        error: (err) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Failed to check uniqueness.',
            life: 4000
          });
        }
      });
    } else {
      this.saveEmployee();
    }
  }

  // Helper to save employee after validation
  private saveEmployee() {
    // Ensure managerId is set to reportingManager's empId if selected
    if (this.formData.reportingManager) {
      this.formData.managerId = this.formData.reportingManager;
    } else {
      this.formData.managerId = '';
    }
    // Set isManagerAssigned to true if managerId is present
    this.formData.isManagerAssigned = !!this.formData.managerId;

    this.apiService.saveUser(this.formData).subscribe({
      next: (res) => {
        if (this.isEditMode) {
          this.showToastSuccess('Employee details updated successfully', 5000);
          setTimeout(() => {
            this.router.navigate(['/employee-list']);
          }, 5000);
        } else {
          this.showToastSuccess('Employee details created successfully', 1500);
          setTimeout(() => {
            this.router.navigate(['/employee-list']);
          }, 1500);
        }
      },
      error: (err) => {
        console.error('Error:', err);
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: this.isEditMode ? 'Failed to update employee details' : 'Failed to create employee details',
          life: 5000
        });
      }
    });
    console.log(this.formData);
  }

  OnCancel() {
    this.router.navigate(['/employee-list']);
  }

  OnReset(form?: any) {
    if (this.isEditMode) {
      this.formData = { ...this.originalData };
    } else {
      const empId = this.formData.empId;
      this.formData = {
        empId: empId,
        managerId: '',
        isManagerAssigned: false, 
        firstName: '',
        middleName: '',
        lastName: '',
        userName: '',      
        dateOfBirth: '',
        mobileNumber: '',
        gender: '',
        address: '',
        email: '', 
        department: '',  
        role: '',
        password: '',
        joiningDate: '',
        reportingManager:'',
        designation:'',
        companyName: '',
        holiday: '',
        timesheet: ''
      };
    }
    if (form) {
      // Reset form but preserve Employee ID value
      form.resetForm({ empId: this.formData.empId });
    }
  }
}