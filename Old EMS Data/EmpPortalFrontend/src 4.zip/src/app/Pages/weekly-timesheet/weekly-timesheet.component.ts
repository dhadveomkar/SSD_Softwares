import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { ApiService } from '../../../services/services';
import { DropdownModule } from 'primeng/dropdown';

interface WeekData {
  weekNo: number;
  startDate: Date;
  endDate: Date;
  fiscalWeek: string;
  month: string;
  year: number;
}

@Component({
  selector: 'app-weekly-timesheet',
  standalone: true,
  imports: [CommonModule, FormsModule, ToastModule, DropdownModule],
  providers: [MessageService],
  templateUrl: './weekly-timesheet.component.html',
  styleUrls: ['./weekly-timesheet.component.css']
})
export class WeeklyTimesheetComponent implements OnInit {
  timesheetRows: any[] = [];
  originalTimesheetRows: any[] = [];
  weekData: WeekData[] = [];
  weekOptions: number[] = [];
  currentYear: number = new Date().getFullYear();
  currentUserName: string = '';
  currentUserEmail: string = '';

  // ===== HEADER WEEK NO DROPDOWN =====
showHeaderDropdown: boolean = false;
selectedHeaderWeekNo: number | null = null;

  filters: any = {
    employeeName: '',
    weekNo: '',
    fiscalWeek: '',
    month: '',
    leaveType: '',
    projectName: '',
    totalWeek: '',
    sunHours: '',
    monHours: '',
    tuesHours: '',
    wedHours: '',
    thursHours: '',
    friHours: '',
    satHours: ''
  };

  showColumnFilter: any = {
    employeeName: false,
    weekNo: false,
    fiscalWeek: false,
    month: false,
    leaveType: false,
    projectName: false,
    totalWeek: false,
    sunHours: false,
    monHours: false,
    tuesHours: false,
    wedHours: false,
    thursHours: false,
    friHours: false,
    satHours: false
  };

  totalWeekSum: number = 0;
  totalSunHours: number = 0;
  totalMonHours: number = 0;
  totalTuesHours: number = 0;
  totalWedHours: number = 0;
  totalThursHours: number = 0;
  totalFriHours: number = 0;
  totalSatHours: number = 0;

  private apiService = inject(ApiService);
  private messageService = inject(MessageService);

  ngOnInit() {
    const firstName = sessionStorage.getItem('userName') || '';
    const lastName = sessionStorage.getItem('userLastName') || '';
    const userEmail = sessionStorage.getItem('userEmail') || '';
    
    console.log('Session Storage - userName:', firstName);
    console.log('Session Storage - userLastName:', lastName);
    
    this.currentUserName = `${firstName} ${lastName}`.trim();
    this.currentUserEmail = userEmail;

    console.log('Current User Name:', this.currentUserName);

    this.generateWeekDataForYear(this.currentYear);
    this.loadWeeklyTimesheets();
  }

  generateWeekDataForYear(year: number) {
  this.weekData = [];
  this.weekOptions = [];

  const today = new Date();
  const minDate = new Date();
  minDate.setDate(today.getDate() - 28); // last 4 weeks

  const startOfYear = new Date(year, 0, 1);
  const endOfYear = new Date(year, 11, 31);
  let weekNo = 1;

  let startDate = new Date(startOfYear);

  // Adjust start date to Sunday if not already Sunday
  while (startDate.getDay() !== 0) {
    startDate.setDate(startDate.getDate() - 1);
  }

  while (startDate <= endOfYear) {
    let endDate = new Date(startDate);
    endDate.setDate(startDate.getDate() + 6); // week ends on Saturday

    if (endDate > endOfYear) {
      endDate = new Date(endOfYear);
    }

    this.addWeekIfValid(weekNo++, startDate, endDate, year, minDate);

    startDate = new Date(endDate);
    startDate.setDate(startDate.getDate() + 1);
  }
}


  private addWeekIfValid(
    weekNo: number,
    startDate: Date,
    endDate: Date,
    year: number,
    minDate: Date
  ) {
    if (endDate >= minDate) {
      this.weekData.push({
        weekNo: weekNo,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        fiscalWeek: `${this.formatDateShort(startDate)} - ${this.formatDateShort(endDate)}`,
        month: `${year}-${endDate.toLocaleDateString('en-US', { month: 'short' })}`,
        year: year
      });
      this.weekOptions.push(weekNo);
    }
  }

  private formatDateShort(date: Date): string {
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
  }

  toggleFilter(column: string) {
    this.showColumnFilter[column] = !this.showColumnFilter[column];
  }

  applyFilter() {
    this.timesheetRows = this.originalTimesheetRows.filter(row => {
      return (!this.filters.employeeName || row.employeeName?.toLowerCase().includes(this.filters.employeeName.toLowerCase()))
        && (!this.filters.weekNo || row.weekNo == this.filters.weekNo)
        && (!this.filters.fiscalWeek || row.fiscalWeek?.toLowerCase().includes(this.filters.fiscalWeek.toLowerCase()))
        && (!this.filters.month || row.month?.toLowerCase().includes(this.filters.month.toLowerCase()))
        && (!this.filters.leaveType || row.leaveType?.toLowerCase().includes(this.filters.leaveType.toLowerCase()))
        && (!this.filters.projectName || row.projectName?.toLowerCase().includes(this.filters.projectName.toLowerCase()))
        && (!this.filters.totalWeek || row.totalWeek == Number(this.filters.totalWeek))
        && (!this.filters.sunHours || row.sunHours == Number(this.filters.sunHours))
        && (!this.filters.monHours || row.monHours == Number(this.filters.monHours))
        && (!this.filters.tuesHours || row.tuesHours == Number(this.filters.tuesHours))
        && (!this.filters.wedHours || row.wedHours == Number(this.filters.wedHours))
        && (!this.filters.thursHours || row.thursHours == Number(this.filters.thursHours))
        && (!this.filters.friHours || row.friHours == Number(this.filters.friHours))
        && (!this.filters.satHours || row.satHours == Number(this.filters.satHours));
    });

    this.calculateColumnTotals();
  }

  onWeekNoChange(rowIndex: number) {
    const selectedWeekNo = this.timesheetRows[rowIndex].weekNo;
    const weekNoNumber = Number(selectedWeekNo);

    if (weekNoNumber) {
      const week = this.weekData.find(w => w.weekNo === weekNoNumber);
      if (week) {
        this.timesheetRows[rowIndex].fiscalWeek = week.fiscalWeek;
        this.timesheetRows[rowIndex].month = week.month;
      }
    } else {
      this.timesheetRows[rowIndex].fiscalWeek = '';
      this.timesheetRows[rowIndex].month = '';
    }
  }

  addEmptyRows(count: number) {
    for (let i = 0; i < count; i++) {
      this.timesheetRows.unshift({
        employeeName: this.currentUserName,
        weekNo: null,
        fiscalWeek: '',
        month: '',
        leaveType: '',
        projectName: '',
        totalWeek: 0,
        sunHours: 0,
        monHours: 0,
        tuesHours: 0,
        wedHours: 0,
        thursHours: 0,
        friHours: 0,
        satHours: 0
      });
    }
    this.calculateColumnTotals();
  }

  loadWeeklyTimesheets() {
    this.apiService.getWeeklyTimesheet().subscribe({
      next: (res: any) => {
        if (Array.isArray(res) && res.length > 0) {
          // Filter data to show only the current user's timesheets
          const userTimesheets = res.filter(item => {
            // Check if employeeName matches current user's name
            const itemEmployeeName = item.employeeName || '';
            return itemEmployeeName.toLowerCase().includes(this.currentUserName.toLowerCase()) ||
                   (this.currentUserEmail && item.email === this.currentUserEmail);
          });

          this.timesheetRows = userTimesheets.map(item => ({
            employeeName: item.employeeName || '',
            weekNo: item.weekNo || null,
            fiscalWeek: item.fiscalWeek || '',
            month: item.month || '',
            leaveType: item.leaveType || '',
            projectName: item.projectName || '',
            totalWeek: item.totalWeekHours || 0,
            sunHours: item.sunHours || 0,
            monHours: item.monHours || 0,
            tuesHours: item.tuesHours || 0,
            wedHours: item.wedHours || 0,
            thursHours: item.thursHours || 0,
            friHours: item.friHours || 0,
            satHours: item.satHours || 0
          }));

          this.timesheetRows.sort((a, b) => (b.weekNo || 0) - (a.weekNo || 0));
          this.originalTimesheetRows = [...this.timesheetRows];
          
          // Add empty rows only if user has less than 5 timesheets
          this.addEmptyRows(Math.max(0 - userTimesheets.length, 0));
        } else {
          // No data found, add empty rows for current user
          this.addEmptyRows(0);
        }
        this.calculateColumnTotals();
      },
      error: (err) => {
        // On error, still add empty rows for current user
        this.addEmptyRows(0);
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: err.error?.message || 'Failed to load timesheets.'
        });
      }
    });
  }

  addRow() {
    this.addEmptyRows(1);
  }

  calculateTotalWeek(rowIndex: number) {
    const row = this.timesheetRows[rowIndex];
    const total = (Number(row.sunHours) || 0) +
      (Number(row.monHours) || 0) +
      (Number(row.tuesHours) || 0) +
      (Number(row.wedHours) || 0) +
      (Number(row.thursHours) || 0) +
      (Number(row.friHours) || 0) +
      (Number(row.satHours) || 0);

    row.totalWeek = Math.round(total * 2) / 2;
    this.calculateColumnTotals();
  }

  saveTimesheets() {
    // Filter only rows that belong to current user and are valid
    const timesheetsToSave = this.timesheetRows.filter(row =>
      row.employeeName && 
      row.weekNo && 
      row.fiscalWeek && 
      row.month &&
      // Ensure we only save rows for the current user
      row.employeeName.toLowerCase().includes(this.currentUserName.toLowerCase())
    );

    if (timesheetsToSave.length === 0) {
      this.messageService.add({
        severity: 'warn',
        summary: 'Warning',
        detail: 'Please fill at least one row to save.'
      });
      return;
    }

    const payload = timesheetsToSave.map(row => ({
      employeeName: this.currentUserName, // Always use current user's name
      weekNo: row.weekNo,
      fiscalWeek: row.fiscalWeek,
      month: row.month,
      leaveType: row.leaveType || '',
      projectName: row.projectName || '',
      totalWeekHours: row.totalWeek,
      sunHours: row.sunHours,
      monHours: row.monHours,
      tuesHours: row.tuesHours,
      wedHours: row.wedHours,
      thursHours: row.thursHours,
      friHours: row.friHours,
      satHours: row.satHours
    }));

    this.apiService.saveWeeklyTimesheet(payload).subscribe({
      next: (res: any) => {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: res.message || 'Timesheet saved successfully!'
        });
        this.loadWeeklyTimesheets();
      },
      error: (err: any) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: err.error?.message || 'Error saving timesheets.'
        });
      }
    });
  }

  calculateColumnTotals() {
    this.totalWeekSum = 0;
    this.totalSunHours = 0;
    this.totalMonHours = 0;
    this.totalTuesHours = 0;
    this.totalWedHours = 0;
    this.totalThursHours = 0;
    this.totalFriHours = 0;
    this.totalSatHours = 0;

    this.timesheetRows.forEach(row => {
      this.totalWeekSum += Number(row.totalWeek) || 0;
      this.totalSunHours += Number(row.sunHours) || 0;
      this.totalMonHours += Number(row.monHours) || 0;
      this.totalTuesHours += Number(row.tuesHours) || 0;
      this.totalWedHours += Number(row.wedHours) || 0;
      this.totalThursHours += Number(row.thursHours) || 0;
      this.totalFriHours += Number(row.friHours) || 0;
      this.totalSatHours += Number(row.satHours) || 0;
    });

    this.totalWeekSum = Math.round(this.totalWeekSum * 10) / 10;
    this.totalSunHours = Math.round(this.totalSunHours * 10) / 10;
    this.totalMonHours = Math.round(this.totalMonHours * 10) / 10;
    this.totalTuesHours = Math.round(this.totalTuesHours * 10) / 10;
    this.totalWedHours = Math.round(this.totalWedHours * 10) / 10;
    this.totalThursHours = Math.round(this.totalThursHours * 10) / 10;
    this.totalFriHours = Math.round(this.totalFriHours * 10) / 10;
    this.totalSatHours = Math.round(this.totalSatHours * 10) / 10;
  }

  onHourChange(rowIndex: number) {
    this.calculateTotalWeek(rowIndex);
  }

  showDropdownIndex: number | null = null;

  toggleDropdown(index: number) {
    this.showDropdownIndex = this.showDropdownIndex === index ? null : index;
  }

  selectWeek(rowIndex: number, weekNo: number) {
    this.timesheetRows[rowIndex].weekNo = weekNo;
    this.showDropdownIndex = null;
    this.onWeekNoChange(rowIndex);
  }

  getWeekLabel(weekNo: number) {
    const week = this.weekData.find(w => w.weekNo === weekNo);
    return week ? `${week.weekNo} - ${week.fiscalWeek}` : null;
  }

  // ===== HEADER DROPDOWN LOGIC =====
toggleHeaderDropdown() {
  this.showHeaderDropdown = !this.showHeaderDropdown;
}

selectHeaderWeek(weekNo: number) {
  this.selectedHeaderWeekNo = weekNo;
  this.showHeaderDropdown = false;
  this.filterBySelectedWeek(weekNo);
}

filterBySelectedWeek(weekNo: number) {
  if (!weekNo) {
    this.timesheetRows = [...this.originalTimesheetRows];
  } else {
    this.timesheetRows = this.originalTimesheetRows.filter(row => row.weekNo === weekNo);
  }
  this.calculateColumnTotals();
}
}