declare interface INavetPersonalLinksWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'NavetPersonalLinksWebPartStrings' {
  const strings: INavetPersonalLinksWebPartStrings;
  export = strings;
}
